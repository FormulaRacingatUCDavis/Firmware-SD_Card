/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan1;

SD_HandleTypeDef hsd1;
DMA_HandleTypeDef hdma_sdmmc1_rx;
DMA_HandleTypeDef hdma_sdmmc1_tx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SDMMC1_SD_Init(void);
static void MX_CAN1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
	FRESULT res; /* FatFs function common result code */
	DWORD fileSize;
	uint32_t byteswritten, bytesread; /* File write/read counts */
	uint8_t rtext[_MAX_SS];/* File read buffer */

	char buffer[8192];
	char Databuffer[8192];
	char old_Databuffer[8192] = {0};


	CAN_TxHeaderTypeDef TxHeader;
	CAN_RxHeaderTypeDef RxHeader;

	uint8_t TxData[8];
	uint8_t RxData[8];

	uint32_t TxMailbox;



void bufclear(void) //clear buffer
{
	for(int i = 0; i<8192; i++){
		buffer[i] = '\0';
	}
}

void Mount_SD_Card(void){
  uint32_t startTime = HAL_GetTick();


  	 res = f_mount(&SDFatFS, (TCHAR const*)SDPath, 0);
	           //Open file for writing (Create)
	 res = f_open(&SDFile, "CANData.txt",  FA_OPEN_APPEND | FA_OPEN_ALWAYS | FA_WRITE);
	 strcpy (buffer, "This file is for saving CAN Data\n");
	 res = f_write(&SDFile, buffer, strlen((char *)buffer), (void *)&byteswritten);
	 res = f_close(&SDFile);
	 bufclear();
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_FATFS_Init();
  MX_SDMMC1_SD_Init();
  MX_CAN1_Init();
  /* USER CODE BEGIN 2 */
  HAL_CAN_Start(&hcan1);



//FAKE CAN//
  /*
  RxHeader.DLC = 8; //data length
  RxHeader.IDE = CAN_ID_STD;
  RxHeader.RTR = CAN_RTR_DATA;
  RxHeader.StdId = 0xA4; //ID

  RxData[0] = 123; // ms delay
  RxData[1] = 234; // loop rep
  RxData[2] = 345;
  RxData[3] = 1;
  RxData[4] = 2;
  RxData[5] = 3;
  RxData[6] = 98;
  RxData[7] = 34;
  */

Mount_SD_Card();
/*
  if(f_mount(&SDFatFS, (TCHAR const*)SDPath, 0) != FR_OK)
    {
        Error_Handler();
    }
    else
    {
 	   	   	   	   	   	   	   	   	   	   	   	   send_UART("mount Successfully\n");
       // if(res = f_mkfs((TCHAR const*)SDPath, FM_ANY, 0, rtext, sizeof(rtext)) != FR_OK)
      //  {
      //      Error_Handler();
      //  }
     //   else
        {
            //Open file for writing (Create)
            if(f_open(&SDFile, "CANData.txt",  FA_OPEN_APPEND | FA_OPEN_ALWAYS | FA_WRITE) != FR_OK)
            {
                Error_Handler();
            }
            else
            {
         	   	   	   	   	   	   	   	   	   	   	send_UART("Open Successfully\n");
         	   strcpy (buffer, "This file is for saving CAN Data\n");
         	   res = f_write(&SDFile, buffer, strlen((char *)buffer), (void *)&byteswritten);
         	  // res = f_write(&SDFile, buffer, strlen((char *)wtext), (void *)&byteswritten);
                if((byteswritten == 0) || (res != FR_OK))
                {
                    Error_Handler();
                }
                else
                {
             	   	   	   	   	   	   	   	   	   	   send_UART("Write Successfully\n");
             	   	   	   	   	   	   	   	   	   	   send_UART(buffer);

                    f_close(&SDFile);
                    bufclear();
                }
            }
        }
    }
    */

       void CAN(void){ //keep saving data even though no change
		 /* if(HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_3) == GPIO_PIN_RESET){
			  TxSetup1();
			  HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
			  HAL_Delay(10);
			  }
		  else if(HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_3) == GPIO_PIN_SET){
				  TxSetup2();
				 HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
				 HAL_Delay(10);
			  }
			  if(TxHeader.StdId == 0x446){
				  HAL_GPIO_WritePin (GPIOF, GPIO_PIN_14, GPIO_PIN_SET); //LED ON
				  } else {
					  HAL_GPIO_WritePin (GPIOF, GPIO_PIN_14, GPIO_PIN_RESET);
				  }
				  */


  				res = HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, &RxData);
  				int TimeRightAfter_Get_From_Slave = HAL_GetTick();

  					res =f_open(&SDFile, "CANData.txt",  FA_OPEN_APPEND | FA_WRITE);

  					sprintf(buffer,"%X, %d, %d, %d, %d, %d, %d, %d, %d, %d \n ", RxHeader.StdId, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7], TimeRightAfter_Get_From_Slave );
  					f_write(&SDFile, buffer, strlen((char *)buffer), (void *)&byteswritten);

  					f_close(&SDFile);
  					bufclear();
     }


    /*
	   void CAN(void){ //Save data only when the data changed
			  if(HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_3) == GPIO_PIN_RESET){
				  TxSetup1();
				  HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
				  HAL_Delay(10);
				  }
			  else if(HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_3) == GPIO_PIN_SET){
					  TxSetup2();
					 HAL_CAN_AddTxMessage(&hcan1, &TxHeader, TxData, &TxMailbox);
					 HAL_Delay(10);
				  }
				  if(TxHeader.StdId == 0x446){
					  HAL_GPIO_WritePin (GPIOF, GPIO_PIN_14, GPIO_PIN_SET); //LED ON
					  } else {
						  HAL_GPIO_WritePin (GPIOF, GPIO_PIN_14, GPIO_PIN_RESET);
					  }




	     				HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, &RxData);
	     				int TimeRightAfter_Get_From_Slave = HAL_GetTick();

	 						sprintf(Databuffer,"%X, %d, %d, %d, %d, %d, %d, %d, %d, \n ", RxHeader.StdId, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7]);
	 					if(strcmp(Databuffer, old_Databuffer) != 0){
	 						res = f_open(&SDFile, "CANData.txt",  FA_OPEN_APPEND | FA_WRITE);
	 						sprintf(buffer,"%X, %d, %d, %d, %d, %d, %d, %d, %d, %d \n ", RxHeader.StdId, RxData[0], RxData[1], RxData[2], RxData[3], RxData[4], RxData[5], RxData[6], RxData[7], TimeRightAfter_Get_From_Slave );
	     					res = f_write(&SDFile, buffer, strlen((char *)buffer), (void *)&byteswritten);

	     					f_close(&SDFile);
	     				    strcpy(old_Databuffer, Databuffer);
	     					//send_UART(buffer);
	     					//bufclear();
	 					}
	        }
	   */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  CAN();

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 96;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 24;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_1TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

  CAN_FilterTypeDef canfilterconfig;

      canfilterconfig.FilterActivation = CAN_FILTER_ENABLE;
      canfilterconfig.FilterBank = 18; //anything between 0 to SlaveStartFilterBank
      canfilterconfig.FilterFIFOAssignment = CAN_RX_FIFO0; //Using FIFO#0
      canfilterconfig.FilterIdHigh = 0x00;
      canfilterconfig.FilterIdLow = 0;
      canfilterconfig.FilterMaskIdHigh = 0 << 5;
      canfilterconfig.FilterMaskIdLow = 0x0000;
      canfilterconfig.FilterMode = CAN_FILTERMODE_IDMASK; //or CAN_FILTERMODE_IDLIST mode
      canfilterconfig.FilterScale = CAN_FILTERSCALE_32BIT; //
      canfilterconfig.SlaveStartFilterBank = 20; //13 to 27 are assigned to Slave CAN(CAN2) or 0 to 12 are assigned to Master CAN(CAN1)

      HAL_CAN_ConfigFilter(&hcan1, &canfilterconfig);

  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief SDMMC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDMMC1_SD_Init(void)
{

  /* USER CODE BEGIN SDMMC1_Init 0 */

  /* USER CODE END SDMMC1_Init 0 */

  /* USER CODE BEGIN SDMMC1_Init 1 */

  /* USER CODE END SDMMC1_Init 1 */
  hsd1.Instance = SDMMC1;
  hsd1.Init.ClockEdge = SDMMC_CLOCK_EDGE_RISING;
  hsd1.Init.ClockBypass = SDMMC_CLOCK_BYPASS_DISABLE;
  hsd1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
  hsd1.Init.BusWide = SDMMC_BUS_WIDE_1B;
  hsd1.Init.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
  hsd1.Init.ClockDiv = 0;
  /* USER CODE BEGIN SDMMC1_Init 2 */

  /* USER CODE END SDMMC1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream3_IRQn);
  /* DMA2_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream6_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
